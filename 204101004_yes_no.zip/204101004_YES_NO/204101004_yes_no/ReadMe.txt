
size of each frame = 320 sample

calculating energy for each frame and storing it in the vector(STE)

calculating ZCR for each frame and storing it in the vector(ZCR)

Marking voiced and unvoiced part 

if there 5 times increase in STE then it is voiced starting

For ending of voice if we found frame with STE less than equals ( STE of frame just before starting part + 20)

Minimum size of Voiced part should consist atleast 15 frames( it is done such that there may be sudden spike due to noise so to not consider the

if average ZCR for last 15 frames > 40 then "YES" otherwise "NO"




To run the Program : 

software - Microsoft visual studio professional 2010




file.open("input1.txt",ios::in);  // ( for checking other replace input1.txt with other file name ( input2.txt )

input1.txt is sir voice

Build -> Build Solution -> Debug -> Start Without Debugging

Screen will print YES/NO sequence according to input file

