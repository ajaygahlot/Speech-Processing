To run the Program : 

software - Microsoft visual studio professional 2010

Build -> Build Solution -> Debug -> Start Without Debugging



Console will give three choice -------->

1) Training - it will create reference file for each vowel ( train on 10 files of each vowel )

2) Testing - it will test 10 files of each vowel

3) Live Recording - Recodring will start for 3 seconds and then press any key to see the predicted result


vowel recording are in train and test folder 

file_a,file_e,file_i,file_o,file_u are reference file created using training dataset