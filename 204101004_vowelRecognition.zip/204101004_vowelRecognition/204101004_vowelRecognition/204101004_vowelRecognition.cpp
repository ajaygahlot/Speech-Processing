// 204101004_vowelRecognition.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


#include<iostream>
#include<vector> 
#include <stdio.h>
#include<math.h>
#include <sstream>
#include<fstream>
#include <iomanip>
#include<string>


using namespace std;

#define PI 3.14159265

#define N 320  // no of samples in one frame 

#define p 12   

char vowels[] = {'a','e','i','o','u'};

/* read_file() function is used to read .txt file */



vector<long double> read_file(string filename)
{
	
	fstream file;
	vector<long double>Sample;
	file.open(filename,ios::in);              
	if(file.is_open())
	{
		
		string line; 
		while(getline(file,line))                       // reading line by line
		{

				long double num = stod(line);					// get the double value for string 

				Sample.push_back(num);
		}		
		file.close();
	}

	return Sample;  // storing values(line by line) present in filename.txt file in vector Sample
}
   

/* DC shift */


void DCShift( vector<long double>&samples )
{
	
	// avg contain the value we have to remove from each sample so to remove DC shift 
	double sum = 0;

	for(int i=0;i<samples.size();i++)
	{
		sum = sum + samples[i];
	}

	double avg = sum*1.0/samples.size();

	// removing avg from each sample

	for(int i=0;i<samples.size();i++)
	{
		samples[i] = samples[i] - avg;
	}

}

/* Normalization */

void Normalization( vector<long double>&samples )
{

	// resizing max value of samples to 10000 
	
	double max_value = samples[0];

	for(int i=1;i<samples.size();i++)
	{
		if(max_value > samples[i])
		{
			max_value = samples[i];
		}
	}

	
	float factor = 10000.0/max_value;

	for(int i=0;i<samples.size();i++)
	{
		samples[i] = samples[i]*factor;
	}

}

/* creating frame each of 320 samples */

vector<vector<long double>> framing(vector<long double>&samples)
{
	

	vector< vector<long double> >Frames;

	vector<long double>temp;

	for(int i=0;i<samples.size();i=i+1)
	{
		if(i%320 == 0 && i!=0)
		{
			Frames.push_back(temp);

			temp.clear();
		}

		temp.push_back(samples[i]);
	}
			
	return Frames;
}


/* For applying hamming window on frame */

void hamming_window(vector<double>&s)
{
	for(int i=0;i<s.size();i++)
	{
		s[i] = s[i] * (0.54 - 0.46*cos(2*PI*i/319));
	}
}


/* Correlation() is used to find R's for a frame */

vector<long double> Correlation(vector<long double>&s)
{
	vector<long double>R(13,0);

	for(int i=0;i<=12;i++)
	{
		for(int j=0;j<=N-1-i;j++)
		{
			R[i] += s[j]*s[j+i];
		}
	}

	return R;
}


/* Levinson durbin algorithm -------- used to find a_i's for a frame */

vector<long double> Levinson_durbin(vector<long double>&R)
{
	

	vector<long double>E(13,0);
	
	vector<long double>K(13,0);

	long double alpha[13][13];

	memset(alpha,0,sizeof(alpha));
	
	E[0] = R[0];

	for(int i=1;i<=p;i++)
	{
		
		K[i] = R[i];

		long double sum = 0;

		for(int j=1;j<=i-1;j++)
		{
			
			sum += alpha[i-1][j]*R[i-j];
		}

		K[i] = (K[i] - sum)/E[i-1];

		alpha[i][i] = K[i];


		for(int j=1;j<=i-1;j++)
		{
			alpha[i][j] = alpha[i-1][j] - K[i]*alpha[i-1][i-j];
		}

		E[i] = (1-K[i]*K[i])*E[i-1];
	}

	vector<long double>a;

	for(int i=1;i<=p;i++)
	{
		a.push_back(alpha[p][i]);
	}
	return a;
}


/* It used to find Capestral coefficients for frame */

vector<long double>capestral_coefficients(vector<long double>&A,vector<long double>&R)
{
	vector<long double>C(13,0);

	C[0] = log(R[0]*R[0])/log(long double(2));

	for(int m=1;m<=12;m++)
	{
		C[m] = A[m-1];

		for(int k=1;k<m;k++)
		{
			C[m] += (k*1.0/m)*C[k]*A[m-k-1];
		}
	}

	return C;
}

/* applying raisine sine window on C */
void raisine_sine_window(vector<long double>&C)
{
	int Q = 12;

	vector<long double>w(Q+1,0);

	for(int m=1;m<=Q;m++)
	{
		w[m] = 1 + Q*sin(PI*m*1.0/Q)/2.0;
	}

	for(int i=1;i<C.size();i++)
	{
		C[i] *= w[i];
	}
}

// selecting 5 frames from all the Frames(f) first finding frame with highest shortest term energy(ste) and selecting it along with selecting two frames on LHS and RHS of highest energy 
vector< vector<long double> > select_frames(vector< vector<long double> >&f)
{
	int index = 0;

	long double max_value = 0;

	for(int i=0;i<f.size();i++)
	{
		long double ste = 0;

		for(int j=0;j<f[i].size();j++)
		{
			ste = ste + f[i][j]*f[i][j];
		}

		if(ste > max_value)
		{
			max_value = ste;

			index = i;
		}
	}

	vector< vector<long double> >frames;

	frames.push_back(f[index-2]);

	frames.push_back(f[index-1]);

	frames.push_back(f[index]);

	frames.push_back(f[index+1]);

	frames.push_back(f[index+2]);

	return frames; // returning 5 frames
}

vector< vector<long double> > C_R; // temporary vector to store Capestral coefficients(12) for 5 frames

void calculate_CR(vector<long double>&Sample)
{


	DCShift(Sample); // applying DC shift

	Normalization(Sample); // applying normalization

	vector< vector<long double> >f = framing(Sample); // creating frame of 320 samples each

	vector< vector<long double> >frames = select_frames(f); // selecting 5 frames

	// applying these operation on each 5 frames 

	for(int i=0;i<frames.size();i++)
	{

		vector<long double> R = Correlation(frames[i]); // calculate R

		vector<long double> a = Levinson_durbin(R); // calculate a

		vector<long double> C = capestral_coefficients(a,R); // calculate C

		raisine_sine_window(C); // applying raise sine window on C
	
		C_R.push_back(C);

	}

}

// Tokhuras distance for test capestral coefficient(c_t) and reference capestral coefficient(c_r) of 5 frames

long double Tokhuras_distance(vector<long double>&c_t,vector<long double>&c_r)
{

	// size of c_t = size of c_r = 60 = (5 frames) * (12 capestral coefficient each)

	long double sum = 0;

	long double w[] = {1.0, 3.0, 7.0, 13.0, 19.0, 22.0, 25.0, 33.0, 42.0, 50.0, 56.0, 61.0};

	for(int i=0;i<5;i++)
	{

		for(int j=0;j<12;j++)
			sum = sum + w[j] * (c_t[i*12 + j] - c_r[i*12 + j])*(c_t[i*12 + j] - c_r[i*12 + j]);
	}

	return sum;
}


void Test()
{

		// test consist of 10 files of each of the 5 vowel ( total files = 50 )

		// files 1,2............10 of each vowel are used testing

		int correct = 0; // no of vowels correctly classified
		
		for(int m=0;m<5;m++)
		{
			
			for(int t=11;t<=20;t++)
			{

				vector<long double>Sample;           
				
				// generating the name of of file to be read

				string filename  =  "Test/204101004_";
				
				filename.push_back(vowels[m]);
				
				filename += "_";
				ostringstream strg;
				strg<< t;
				string s = strg.str();
				filename += s;
				
				filename += ".txt";

				cout<<"testing for "<<filename<<" : ";

				// reading the file 
				Sample = read_file(filename);
				
				// calculating C_R for Sample i.e 12 Ci's for each of the 5 frames
				calculate_CR(Sample);

				vector<long double>c_t; // storing 5*12 = 60 Ci's value in a 1-D vector 
			
				for(int i=0;i<C_R.size();i++)
				{
					for(int j=1;j<=12;j++)
					{
						c_t.push_back(C_R[i][j]);
					}
				}
		
				C_R.clear();

				// comparing c_t with each vowel c_r one with small distance will be predicted

				int distance,index,min_distance;
				
				for(int i=0;i<5;i++)
				{

					// reading the c_r from the .txt file for each vowel

					vector<long double>c_r;

					string filename = "file_";

					filename.push_back(vowels[i]);

					filename = filename + ".txt";
			
					c_r = read_file(filename);

					long double distance = Tokhuras_distance(c_t,c_r); // tokhuras distance
					
					if(i==0)
					{
				
						min_distance = distance;
						index = i;
					}
					else if(min_distance > distance)
					{
						min_distance = distance;
						index = i;
					}
			}
			
			cout<<"Predicted : "<<vowels[index] <<" Actual : "<<vowels[m];
			
			if(index == m)
			{
				correct++;
				

			}

			else
			{
				cout<<" !!incorrect ";
			}

			cout<<"\n";
		}
	}

	cout<<"No of correct Predicted : "<<correct<<"\n";
	cout<<"Accuracy : "<< (correct*1.0/50)*100 <<"%\n";
}





void train()
{

	// files 11,12..............20 of each vowel are used for training

    for(int m=0;m<5;m++)
	{


		for(int t=1;t<=10;t++)
		{

			vector<long double>Sample;      
			
			// generating the name of of file to be read

			
			
			string filename  = "Train/204101004_";
			filename.push_back(vowels[m]);
			filename += "_";
			ostringstream strg;
			strg<< t;
			string s = strg.str();
			filename += s;
			filename += ".txt";

			cout<<"Training the "<<filename<<"\n";

			// reading the file 
			Sample = read_file(filename);
			// calculating C_R for Sample i.e 12 Ci's for each of the 5 frames
			calculate_CR(Sample);
		}

		// now C_R contains 50 rows of capestral coffeicient of vowels[m]
		ofstream myfile;
		string filename = "file_";
		filename.push_back(vowels[m]);
		filename += ".txt";
		cout<<"Created reference file "<<filename<<" for --------- "<<vowels[m]<<"\n";
		myfile.open(filename);

		//we will take average for corrosponding capestral coefficient for each of the frames

		// wrting into file
		for(int i=0;i<5;i++)
		{

			for(int j=i+5;j<C_R.size();j=j+5)
			{
				for(int k=1;k<=12;k++)
				{
					C_R[i][k] = C_R[i][k] + C_R[j][k];
				}

			}
			for(int k=1;k<=12;k++)
			{
				C_R[i][k] = C_R[i][k]*1.0/10;

				myfile << C_R[i][k] << "\n";
			}
		}
		
		C_R.clear();
	}
}

void Live_Recording()
{


	while(true)
	{
		system("Recording_Module.exe 3 input_file.wav input_file.txt");

		vector<long double>Sample = read_file("input_file.txt");   

		calculate_CR(Sample); // calculate CR for each of the 5 frames of input_file

		// storing in c_t 5*12 = 60 values of test file
		vector<long double>c_t;
			
		for(int i=0;i<C_R.size();i++)
		{
			for(int j=1;j<=12;j++)
			{
				c_t.push_back(C_R[i][j]);
			}
		}
		
		C_R.clear();

		// finding vowel with min tokhuras distance with c_t	
		int distance,index,min_distance;
				
		for(int i=0;i<5;i++)
		{

			vector<long double>c_r;

			string filename = "file_";

			filename.push_back(vowels[i]);

			filename = filename + ".txt";
			
			c_r = read_file(filename);

			long double distance = Tokhuras_distance(c_t,c_r);
					
			if(i==0)
			{
				
					min_distance = distance;
					index = i;
			}
			else if(min_distance > distance)
			{
					min_distance = distance;
					index = i;
			}
		}
		cout<<"predicted : "<<vowels[index]<<"\n";

		int num;
		cout<<"Press 1 to exit / any other key to try again\n";
		cin>>num;
		if(num==1)
		{
			break;
		}
	}
	


}




int _tmain(int argc, _TCHAR* argv[])
{

	
	cout<<"Enter 1 for training \n";

	cout<<"Enter 2 for testing ( 50 recordings of 10 vowels each )\n";

	cout<<"Enter 3 for Live Testing\n";

	int input;

	cin>>input;

	if(input==1)
	{
		train();
	}
	else if(input==2)
	{
		Test();
	}
	else
	{
		
		Live_Recording();

	}
	return 0;
}

