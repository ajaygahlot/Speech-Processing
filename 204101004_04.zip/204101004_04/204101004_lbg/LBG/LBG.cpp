// LBG.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<iostream>
#include<fstream>
#include <iomanip>
#include<string>
#include <sstream>
#include<vector>
#include<set>
using namespace std;

long M;// universe file size
int k = 32; // size of codebook vector
vector< vector<long double> >Universe;
vector< vector<long double> >bucket[32];
vector< vector<long double> >codebook;
long double avg_distortion = 0;
long double previous_distortion = 0;

long double epsilon = 0.03;
void readfile()
{
	fstream file;

	file.open("Universe.csv",ios::in);

	if(file.is_open())
	{
		string line;
		
		while(getline(file,line))
		{
			
			stringstream s(line); 

			vector<long double>vec; // temporary vector
			while(getline(s,line,',')) { 
					
				long double num = stod(line);					// get the double value for string 

				vec.push_back(num);
			}
			Universe.push_back(vec);
		}
		file.close();

	}
	else
	{
		cout<<"File Cannot be open\n";
	}
	M = Universe.size();
}

// for doubling the codebook 
void Doubling_Codebook()
{
	

	vector< vector<long double> >newcodebook;
	for(int i=0;i<codebook.size();i++)
	{
		vector<long double>vec1,vec2;
		for(int j=0;j<12;j++)
		{
			vec1.push_back(codebook[i][j]*(1 + epsilon));
			vec2.push_back(codebook[i][j]*(1 - epsilon));
		}
		newcodebook.push_back(vec1);
		newcodebook.push_back(vec2);
	}
	codebook = newcodebook;
}

long double tokhuras_distance(vector<long double>&A,vector<long double>&B)
{
	long double sum = 0;

	long double w[] = {1.0, 3.0, 7.0, 13.0, 19.0, 22.0, 25.0, 33.0, 42.0, 50.0, 56.0, 61.0};

	for(int i=0;i<12;i++)
	{
		sum = sum + w[i] * (A[i] - B[i])*(A[i] - B[i]);
	}

	return sum;
}
void nearestneigbour(vector<long double>&vec)
{

	long double min_dist = INT_MAX;
	int region = 0;
	for(int i=0;i<codebook.size();i++)
	{

		long double dist = tokhuras_distance(codebook[i],vec);
		if(dist < min_dist)
		{
			min_dist = dist;
			region = i;
		}
	}
	bucket[region].push_back(vec);
}
		

void centroid(int region)
{
	for(int i=0;i<12;i++)
	{
		long double temp = 0;
		for(int j=0;j<bucket[region].size();j++)
		{
			temp = temp + bucket[region][j][i];
		}
		temp = temp*1.0/bucket[region].size();
		codebook[region][i] = temp;
	}
}

// to take care of empty cell problem
void emptycellproblem()
{
	long double epsilon = 0.03;
	for(int i=0;i<codebook.size();i++)
	{
		if(bucket[i].size()==0)
		{

			long double max_size=0;
			int clusterindex=0;

			for(int j=0;j<codebook.size();j++)
			{
				if( max_size < bucket[i].size())
				{
					max_size = bucket[i].size();
					clusterindex = j;
				}
			}
			// split using epsilon = 0.03

			for(int j=0;j<bucket[clusterindex].size();i++)
			{
				vector<long double>vec;
				for(int p=0;p<12;p++)
				{
					long double temp = bucket[clusterindex][j][p];
					vec.push_back(temp*(1-epsilon));
					bucket[clusterindex][j][p] = temp*(1+epsilon);
				}
				bucket[i].push_back(vec);
			}
		}
	}
}


void kmeans()
{


	long m = 0;

	while(true)
	{

		for(int i=0;i<codebook.size();i++)
		{
			bucket[i].clear();
		}
		// assigning training vector to the regions(cluster)
		for(long i=0;i<M;i++)
		{
			nearestneigbour(Universe[i]);
		}
		
		// centroid update
		for(int i=0;i<codebook.size();i++)
		{
		
			centroid(i);
		}

		emptycellproblem();
	// calculation avg distortion

		avg_distortion = 0;
		for(int i=0;i<codebook.size();i++)
		{
			for(int j=0;j<bucket[i].size();j++)
			{
				
				avg_distortion += tokhuras_distance(bucket[i][j],codebook[i]);
			}
		}
		avg_distortion = avg_distortion*1.0/M;
		
		m = m + 1;
		
		cout<<"Iteration : "<<m<<" Avgerage distortion : "<<avg_distortion<<" Decrease in distortion : ";
		printf("%.6Lf\n",abs(previous_distortion-avg_distortion));
		

		if(m>200 || (m>1 && abs(previous_distortion - avg_distortion)<0.00001))
		{
			
			//cout<<m<<"\n";
			break;
		}
		previous_distortion = avg_distortion;
	}

}

void LBG()
{
	vector<long double>vec;

	// calculating centroid for the entire universe(i.e 1 size codebook)
	for(int i=0;i<12;i++)
	{
		long double temp = 0;
		for(int j=0;j<Universe.size();j++)
		{
			temp = temp + Universe[j][i];
		}
		temp = temp*1.0/Universe.size();

		vec.push_back(temp);
	}
	codebook.push_back(vec);
	
	// run until codebook = 8

	while(codebook.size() < k)
	{

		Doubling_Codebook(); // double the codebook
		cout<<"K-means for codebook size "<<codebook.size()<<" : \n";
		kmeans(); // kmeans
		cout<<"\n";
	}
	
}
int main()
{
	
	readfile();
	cout<<"Running LBG algorithm.........\n\n";
	
	LBG();
	
	cout<<"\nWe get the following codebook : \n\n";
	
	ofstream MyFile("codebook.txt");
	
	for(int i=0;i<codebook.size();i++)
	{
		for(int j=0;j<12;j++)
		{

			MyFile << codebook[i][j]<<" ";
		}
		MyFile << "\n";
	}

	// Close the file
	MyFile.close();
	
}