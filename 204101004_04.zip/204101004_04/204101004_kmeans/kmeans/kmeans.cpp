// kmeans.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<iostream>
#include<fstream>
#include <iomanip>
#include<string>
#include <sstream>
#include<vector>
#include<set>
using namespace std;

long M;// universe file size
int k = 32; // size of codebook vector
vector< vector<long double> >Universe; // to store M training set(x) { each training set consist of 12 capestral coefficicent }
vector< vector<long double> >bucket[32];// bucket to store which training vector assigned to that region
vector< vector<long double> >codebook; // to store the centroid
long double avg_distortion = 0;
long double previous_distortion = 0;


/* for reading the universe.csv file and storing in Universe 2D vector */
void readfile()
{
	fstream file;

	file.open("Universe.csv",ios::in);

	if(file.is_open())
	{
		string line;
		
		while(getline(file,line))
		{
			
			stringstream s(line); 

			vector<long double>vec; // temporary vector
			while(getline(s,line,',')) { 
					
				long double num = stod(line);					// get the double value for string 

				vec.push_back(num);
			}
			Universe.push_back(vec);
		}
		file.close();

	}
	else
	{
		cout<<"File Cannot be open\n";
	}
	M = Universe.size();
}

/* tokhuras distance*/
long double tokhuras_distance(vector<long double>&A,vector<long double>&B)
{
	long double sum = 0;

	long double w[] = {1.0, 3.0, 7.0, 13.0, 19.0, 22.0, 25.0, 33.0, 42.0, 50.0, 56.0, 61.0};

	for(int i=0;i<12;i++)
	{
		sum = sum + w[i] * (A[i] - B[i])*(A[i] - B[i]);
	}

	return sum;
}


/* nearest neighbour selection rule*/
void nearestneigbour(vector<long double>&vec)
{

	long double min_dist = INT_MAX;
	int region = 0;
	for(int i=0;i<codebook.size();i++)
	{

		long double dist = tokhuras_distance(codebook[i],vec);
		if(dist < min_dist)
		{
			min_dist = dist;
			region = i;
		}
	}
	bucket[region].push_back(vec);
}
		
// to calculate the centroid 
void centroid(int region)
{

	for(int i=0;i<12;i++)
	{
		long double temp = 0;
		for(int j=0;j<bucket[region].size();j++)
		{
			temp = temp + bucket[region][j][i];
		}
		temp = temp*1.0/bucket[region].size();
		codebook[region][i] = temp;
	}
}

/* kmeans */
void kmeans()
{

	// picking k random vectors

	set<long>s;

	srand(time(0));

	while(s.size()<k)
	{
		s.insert(rand()%M);
	}

	for(auto itr=s.begin();itr!=s.end();itr++)
	{
		codebook.push_back(Universe[*itr]);
	}

	long m = 0;

	
	/* running iteration of kmeans */
	while(true)
	{
	
		avg_distortion = 0;
		/* assign each codebook vector */
		
		for(int i=0;i<32;i++)
		{
			bucket[i].clear();
		}

		// assigning training vector to the regions(cluster)
		for(long i=0;i<M;i++)
		{
			nearestneigbour(Universe[i]);
		}

		// updating the centroid
		for(int i=0;i<k;i++)
		{
			centroid(i);
		}

		// calculation avg distortion
		for(int i=0;i<32;i++)
		{
			for(int j=0;j<bucket[i].size();j++)
			{
				avg_distortion += tokhuras_distance(bucket[i][j],codebook[i]);
			}
		}
		
		avg_distortion = avg_distortion*1.0/M;
		
		m = m + 1;

		cout<<"Iteration : "<<m<<" Avgerage distortion : "<<avg_distortion<<" Decrease in distortion : ";
		printf("%Lf\n",abs(previous_distortion-avg_distortion));
		if(m>1 && abs(previous_distortion-avg_distortion) < 0.00001)
		{
			break;
		}
		previous_distortion = avg_distortion;
	}
}


int _tmain(int argc, _TCHAR* argv[])
{

	readfile();
	
	cout<<"Running kmeans algorithm.........\n\n";
	kmeans();

	
	cout<<"\nWe get the following codebook : \n\n";
	for(int i=0;i<codebook.size();i++)
	{
		for(int j=0;j<12;j++)
		{
			cout<<j+1<<"-> "<<codebook[i][j]<<"   ";
		}
		cout<<"\n\n";
	}
	cout<<"\n";

	return 0;
}

