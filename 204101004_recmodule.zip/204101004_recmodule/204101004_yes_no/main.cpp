// 204101004_yes_no.cpp : Defines the entry point for the console application.
//


#include "stdafx.h"

#include<iostream>

#include<fstream>

#include<string>

#include<vector>

using namespace std;



int _tmain(int argc, _TCHAR* argv[])
{


	system("Recording_Module.exe 3 input_file.wav input_file.txt");

	vector<long long>Sample;           // vector for keeping the Sample values



	
	// reading the input file of audio in ASCII	format(.txt)
	
	
	fstream file;																	


	file.open("input_File.txt",ios::in);              // reading the input.txt file
	
	if(file.is_open())
	{

		string line; 

		while(getline(file,line))                       // reading line by line
		{
			long long num = stoi(line);					// get the integer value for string 

			Sample.push_back(num);
			
		}
		
		file.close();
	}


	// size of frame = 320 samples

	vector<long long>ZCR;     // vector for storing the ZCR(zero crossing rate) for each frame 

	vector<long long>STE;	  // vector for storing the STE(short term energy) for each frame 
	
	long long count = 0;      // counter for each sample in a particular frame

	long long E = 0;   // variable for storing STE for calculationg each frame

	long long Z = 0;   // variable for storing ZCR for calculationg each frame

	for(int i=0;i<Sample.size();i++)
	{
			E += (Sample[i]*Sample[i]);        // contribution of each sample to STE of frame Sample[i]*Sample[i]

			if(i%320 != 0)             // if not the first sample of frame
			{
				if(Sample[i]*Sample[i-1] < 0)        // if it crosses X-axis
				{
					Z++; // increamenting the value the ZCR for frame
				}
			}

			count = count + 1;

			if(count%320 == 0)            // if last sample of frame (modulus of 320)
			{
				ZCR.push_back(Z);
				STE.push_back(E/320);

				E = 0;
				Z = 0;
			}
	}


	// voiced and unvoiced part

	vector< pair<long,long> > Voice_Marker; // Marker for voiced part ( start and end )  
	
	int i=3; // counter for each frame
	
	int start=-1;
		
	int end;
	
	long long temp;     // maintaing the value frame STE for last start-1
	
	while(i<ZCR.size())
	{
		if(start==-1 &&  STE[i-1]!=0 && STE[i]/STE[i-1] >= 5)          // if there is spike of energy more than 125 than it can be voiced part
		{

			start = i; 
			temp = STE[start-1];
		}

		else if(start!=-1 &&  STE[i] < temp + 20) 
		{
			end = i;
			pair<long long ,long long>p;
			p.first = start;
			p.second = end;
			Voice_Marker.push_back(p);
			start = -1;
		}

		i=i+1;
	}


	// YES or No classification of Voiced Part
	
	for(int i=0;i<Voice_Marker.size();i++)
	{


		int a = Voice_Marker[i].first;
		int b = Voice_Marker[i].second;
		

		int count=0;


		if(b-a >= 15)         // each voiced part should have min 15 frames
		{

			// taking average for last 15 Frame of Voiced part

			for(int j=b;j>=b-15;j--)
				count += ZCR[j];

			if(count/15 > 40)       // if average ZCR is greater than 40 for last 15 frame than "YES"        
			{
				cout<<"Yes\n";
			}
			else
			{
				cout<<"No\n";
			}
		}
	}

	return 0;
}


